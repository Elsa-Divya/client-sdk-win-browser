function payCard(amount,mode,options){
	var deferred=$.Deferred();
	EzeAPI.cardTransaction(amount,mode,options,function(response){
		if((response!=null && response!='undefined') && response.error==null){
				deferred.resolve(response)
			
		}else
			deferred.reject(response)
		
	})
	return deferred.promise();
}

function payCash(amount,options){
	var deferred=$.Deferred();
	EzeAPI.cashTransaction(amount,options,function(response){
		if((response!=null || response!='undefined') && response.error==null){
			deferred.resolve(response)
		
		}else
			deferred.reject(response)
		
		})
	return deferred.promise();
}

function getTransaction(txnId){
	var deferred=$.Deferred();
	EzeAPI.getTransaction(txnId,function(response){
		if((response!=null || response!='undefined') && response.error==null){
			deferred.resolve(response)
		
			}else
				deferred.reject(response)
			
		})
	return deferred.promise();
}

function payCheque(amount,cheque,options){
	var deferred=$.Deferred();
	EzeAPI.chequeTransaction(amount,cheque,options,function(response){
		if((response!=null || response!='undefined') && response.error==null){
			deferred.resolve(response)
		
			}else
				deferred.reject(response)
			
		})
	return deferred.promise();
}


function initializeClient(data){
	var deferred=$.Deferred();
	EzeAPI.initialize(data,function(response){
		if((response!=null || response!='undefined') && response.error==null){
			deferred.resolve(response)
		
			}else
				deferred.reject(response)
			
		})
	return deferred.promise();
}

function voidTransactionClient(txnId){
	var deferred=$.Deferred();
	EzeAPI.voidTransaction(txnId,function(response){
		if((response!=null || response!='undefined') && response.error==null){
			deferred.resolve(response)
		
			}else
				deferred.reject(response)
			
		})
	return deferred.promise();
}

function logoutClient(){
	var deferred=$.Deferred();
	try{
		EzeAPI.close(function(response){
			try{
				if(response.error==null)
					deferred.resolve(response)
				else
					deferred.reject(response)
			}catch(e){
				deferred.reject(response)
			}
			
		})
	}catch(e){
		deferred.reject(response);
	}
	
	return deferred.promise();
}