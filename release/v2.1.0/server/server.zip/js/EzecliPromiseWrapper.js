var Q=require('q');
var https = require('http');
var log=require('./logger');
var	logger = log.getLogger('ezeClient-appender');
function EzecliWrapper(eze){
	var that=this;

	that.prepareDevice=function(){
		var deferred=Q.defer();
		try{
			
			eze.preparedevice(function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
					deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}		
					
			});
		}catch(e){
			deferred.reject();
		}
		
		
		return deferred.promise;
	}

	that.login=function(username,password,loginmode){
		var deferred=Q.defer();
		try{
			eze.login(username,password,loginmode,function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
						deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}
					
			});
		}catch(e){
			deferred.reject();
		}
		
		
		return deferred.promise;
	}

	that.logout=function(){
		var deferred=Q.defer();
		try{
			
			eze.logout(function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
					deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}
			});
		}catch(e){
			deferred.reject();
		}
		
		return deferred.promise;
	}

	that.stop=function(){
		var deferred=Q.defer();
		try{
			eze.stop()
			deferred.resolve();
		}catch(e){
			deferred.reject();
		}
		
		return deferred.promise;
	}

	that.payCard=function(amount,options){
		var deferred=Q.defer();
		try{
			eze.paycard(amount,options,function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
					deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}
			});
		}catch(e){
			deferred.reject();
		}
		
		return deferred.promise;
	}

	that.payCardCash=function(amount,otherAmount,options){
		var deferred=Q.defer();
		try{
			eze.paycardCash(amount,otherAmount,options,function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
					deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}
			});
		}catch(e){
			deferred.reject();
		}
		
		
		return deferred.promise;
	}

	that.payCash=function(amount,options){
		var deferred=Q.defer();
		try{

			eze.paycash(amount,options,function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
					deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}
			});
		}catch(e){
			deferred.reject();
		}
		
		
		return deferred.promise;
	}

	that.payCheque=function(amount,options){
		var deferred=Q.defer();
		try{

			eze.paycheque(amount,options,function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
					deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}
			});
		}catch(e){
			deferred.reject();
		}
		
		
		return deferred.promise;
	}

	that.voidTransaction=function(txnId){
		var deferred=Q.defer();
		try{

			eze.txnvoid(txnId,function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
					deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}
			});
		}catch(e){
			deferred.reject();
		}
		
		
		return deferred.promise;
	}

	that.sendReceipt=function(txnId,mobile,email){
		var deferred=Q.defer();
		try{
			
			eze.forwardreceipt(txnId,mobile,email,function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
					deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}
			});
		}catch(e){
			deferred.reject();
		}
		
		return deferred.promise;
	}

	that.getTransaction=function(txnId){
		var deferred=Q.defer();
		try{
			
			eze.txndetail(txnId,function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
					deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}	
			});
		}catch(e){
			deferred.reject();
		}
		
		return deferred.promise;
	}

	that.searchTransaction=function(startDate,endDate){
		var deferred=Q.defer();
		try{
			
			eze.txnhistory(startDate,endDate,function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
					deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}
			});
		}catch(e){
			deferred.reject();
		}
		
		return deferred.promise;
	}

	that.setServerType=function(serverType){
		var deferred=Q.defer();
		try{	
			eze.setServerType(serverType,function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
						deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}
			});
		}catch(e){
			deferred.reject();
		}
		
		return deferred.promise;
	}

	that.getDefaultErrorMessage = function(message){
		var response = {};
		response.result = null;
		response.status = "FAILURE";
		response.error = {};
		response.error.message = message;
		return response;
	}

	that.errorDefault = "Something went wrong. Please retry again";
	that.errorNetDown = "Connection failed. Check your Internet connection.";
	that.errorParsing = "Error occurred while parsing the response.";

	that.doPostCall=function(chargeJson,fn){
		try{
			var chargeJson=JSON.stringify(chargeJson);
			var postheaders = {
			    'Content-Type' : 'application/json',
			    'key':ezetapRestImpl.appKey
			};
			var optionspost = {
			    host : 'services-demo.ezetap.com',
			    port : 80,
			    path : '/charge_api/v1/charges/',
			    method : 'POST',
			    headers : postheaders
			};

			returnErrorObj = function(message){
				var error = {};
				error.message = message;
				return error;
			};

			

			var reqPost = https.request(optionspost, function(res) {
			 	var response="";
			 	res.setEncoding('utf8');
			    res.on('data', function(d) {
			    	response+=d;
			    });

			    res.on('end',function(e){
			    	try{
			    		response = JSON.parse(response);
						var resOut = {};
						if('status' in response === false)
							resOut.status = "FAILURE";
						else
							resOut.status = response.status;
						if('error' in response){
							if(typeof response.error === 'string'){
								resOut.error = returnErrorObj(response.error);
							}else if(typeof response.error === 'object'){
								resOut.error = response.error;
							}else{
								if("SUCCESS" != resOut.status){
									resOut.error = returnErrorObj(that.errorDefault);
								}else
									resOut.error = null;
							}
						}else{
							if("SUCCESS" != resOut.status){
								resOut.error = returnErrorObj(that.errorDefault);
							}else
								resOut.error = null;
						}
						if('result' in response == false)
							resOut.result = null;
						else{
							resOut.result = {};
							resOut.result = response.result;
						}
						fn(JSON.stringify(resOut));
			    	}catch(error){
			    		logger.info(that.errorParsing+error);
			    		fn(JSON.stringify(that.getDefaultErrorMessage(that.errorParsing)));
			    	}
				});
			});

		reqPost.write(chargeJson);
		reqPost.end();

		reqPost.on('error', function(error) {
			logger.info(that.errorNetDown+error);
			fn(JSON.stringify(that.getDefaultErrorMessage(that.errorNetDown)));			
		});
		
		
		}catch(e){
			logger.debug('error happened');
			logger.debug(e);
			//deferred.reject();
		}
	}

}

module.exports = {
    EzecliWrapper: function(ezecli)  {
		var instance=new EzecliWrapper(ezecli);
		return instance;
    }
  }